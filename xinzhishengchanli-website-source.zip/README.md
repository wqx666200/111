# 新质生产力数据观察站

一个单页中文数据可视化网站，围绕生产制造、医疗健康、农业资源和绿色能源，展示 AI 对社会生活的可能帮助。

## 本地预览

下载并解压网站源码包后，直接打开 `index.html` 即可。页面样式和交互代码已嵌入首页，不依赖相邻 CSS/JavaScript 文件。Google Fonts 仅影响字体外观；断网时页面仍可正常显示。

## 数据说明

图表里的数值是明确标注的教学情景示意值，用来解释数据比较与图表读法，不是实测行业数据或效果承诺。替换为真实数据时，应同时注明来源、时间、单位、基线和统计口径。

## 发布到 GitHub Pages

1. 将仓库根目录中的 `index.html`、本说明文件与 `.github/workflows/pages.yml` 推送到 GitHub 的 `main` 或 `master` 分支。
2. 在仓库 Settings → Pages → Build and deployment 中将 Source 设为 GitHub Actions。
3. 等待 Actions 工作流成功，再从 Pages 页面取得网址。

页面为原生静态 HTML，无需安装或构建依赖。
